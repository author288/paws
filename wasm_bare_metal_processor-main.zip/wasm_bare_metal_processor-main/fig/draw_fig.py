import pandas as pd
import matplotlib.pyplot as plt

def draw_cycle_fig1(sheet='Sheet1', fig_name='test.pdf', title='VMM Test'):

    # 读取Excel文件
    file_path = '1.xlsx'
    df = pd.read_excel(file_path, sheet_name=sheet)

    # 提取数据
    operate_numbers = df['benchmark name']
    wasm_cycles = df['PAWS cycle ']
    wasmer_cycles = df['server cycle']
    wasm_time = df['PAWS time (us)']
    wasmer_time = df['server time (us)']
    board_cycles = df['board cycle']
    board_time = df['board time (us)']

    # 设置图表样式

    fig = plt.figure(figsize=(4.5, 2.5))
    plt.rcParams['font.size'] = 7.5

    ax = fig.add_subplot(111)
    ax.set_yscale('log')
    ax.set_ylim(top=10**8)
    ax.set_ylabel('Cycle (log scale)')

    # 给图表添加网格，alpha参数设置透明度，只要横线，不要竖线
    ax.grid(True, linestyle='--', alpha=0.6, axis='y')

    

    # 绘制柱状图
    bar_width = 0.1
    index = range(len(operate_numbers))
    ax.bar(index, wasmer_cycles, bar_width, color='lightblue', label='Server Cycle')
    ax.bar([i + bar_width for i in index], board_cycles, bar_width, color='#0076BD', label='Board Cycle')
    ax.bar([i + 2*bar_width for i in index], wasm_cycles, bar_width, color='darkblue', label='PAWS Cycle')

    ax1 = ax.twinx()
    ax1.set_yscale('log')
    ax1.set_ylim(top=100000)
    ax1.set_ylabel('Time (us)')

    ax1.bar([i + 3*bar_width for i in index], board_time, bar_width, color='#D35F00', label='Board Time')
    ax1.bar([i + 4*bar_width for i in index], wasmer_time, bar_width, color='#FFA459', label='Server Time')
    ax1.bar([i + 5*bar_width for i in index], wasm_time, bar_width, color='#C04929', label='PAWS Time')
    # 设置横轴标签和标题
    ax1.set_xlabel('Benchmark Name')
    # plt.xticks([i + 3*bar_width / 2 for i in index], operate_numbers, rotation=45)
    ax.set_xticks([i + 2*bar_width for i in index])
    ax.set_xticklabels(operate_numbers)

    # 添加图例ax1和ax
    ax.legend(loc='upper left')
    ax1.legend(loc='upper right')

    # 调整布局
    plt.tight_layout()

    # 保存为PDF
    plt.savefig(fig_name, format='pdf')
    # 保存为SVG
    plt.savefig('test.svg', format='svg')

    # 显示图表
    plt.show()


def draw_cycle_fig(sheet='Sheet1', fig_name='test.pdf', title='VMM Test'):

    # 读取Excel文件
    file_path = '1.xlsx'
    df = pd.read_excel(file_path, sheet_name=sheet)

    # 提取数据
    operate_numbers = df['Operate number']
    wasm_cycles = df['PAWS cycle ']
    wasmer_cycles = df['wasmer cycle']

    # 设置图表样式
    plt.figure(figsize=(3.5, 2.5))
    # plt.rcParams['font.family'] = 
    plt.rcParams['font.size'] = 7

    # 绘制柱状图
    bar_width = 0.35
    index = range(len(operate_numbers))

    plt.bar(index, wasm_cycles, bar_width, color='darkblue', label='WASM CPU Cycle')
    plt.bar([i + bar_width for i in index], wasmer_cycles, bar_width, color='lightblue', label='Wasmer Cycle')

    # 设置纵坐标为对数比例
    plt.yscale('log')
    plt.ylim(top=10**9)

    # 设置横轴标签和标题
    plt.xlabel('Operate Number')
    plt.ylabel('Cycle Count (log scale)')
    plt.xticks([i + bar_width / 2 for i in index], operate_numbers, rotation=45)

    # 添加图例
    plt.legend()

    # 调整布局
    plt.tight_layout()

    # 保存为PDF
    plt.savefig(fig_name, format='pdf')
    # 保存为SVG
    plt.savefig('test.svg', format='svg')

    # 显示图表
    plt.show()

def draw_power_fig(sheet='Sheet1', fig_name='test.pdf', title='VMM Test'):

    # 读取Excel文件
    file_path = '1.xlsx'
    df = pd.read_excel(file_path, sheet_name=sheet)

    # 提取数据
    benchmark_names = df['benchmark name']
    wasm_cycles = df['wasm cpu power（mW）']
    wasmer_cycles = df['wasmer power (mW)']

    # 设置图表样式
    plt.figure(figsize=(3.5, 3.6))
    # plt.rcParams['font.family'] = 
    plt.rcParams['font.size'] = 9

    # 绘制柱状图
    bar_width = 0.35
    index = range(len(benchmark_names))

    plt.bar(index, wasm_cycles, bar_width, color='darkorange', label='wasm cpu power (mW)')
    plt.bar([i + bar_width for i in index], wasmer_cycles, bar_width, color='lightorange', label='wasmer power (mW)')

    # 设置纵坐标为对数比例
    plt.yscale('log')
    plt.ylim(top=10**9)

    # 设置横轴标签和标题
    plt.xlabel('Operate Number')
    plt.ylabel('Average Power(mW)')
    plt.title(title)
    plt.xticks([i + bar_width / 2 for i in index], benchmark_names, rotation=45)

    # 添加图例
    plt.legend()

    # 调整布局
    plt.tight_layout()

    # 保存为PDF
    plt.savefig(fig_name, format='pdf')

    # 显示图表
    plt.show()

# main function
if __name__ == '__main__':
    # draw_cycle_fig('vmm scale', 'edge testbench cycle contrast.pdf', 'Cycle Contrast')
    draw_cycle_fig1('edge application benchmark', 'edge testbench cycle contrast.pdf', 'Cycle Contrast')
    # draw_power_fig('edge application benchmark', 'edge testbench power contrast.pdf')